package com.automation.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.automation.pages.BaseClass;
import com.automation.pages.LoginPage;
import com.automation.utility.BrowserFactory;
import com.automation.utility.ExcelDataProvider;

public class LoginTestMarriot extends BaseClass {
	
	
	
	@Test
	public void loginApp()
	{
		
		//ExcelDataProvider excel=new ExcelDataProvider();
		//excel.getStringData("Login", 0, 0)
		
		logger=reports.createTest("Login to Marriot");
		
		LoginPage loginpage=PageFactory.initElements(driver, LoginPage.class);
		
		logger.info("starting Application");
		
		loginpage.loginToMarriot("abcd","1234");
		
		logger.pass("login success");
	
		
	}

}
